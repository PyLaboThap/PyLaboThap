from setuptools import setup, find_packages

setup(
    name='PyLaboThap',          # Nom du package
    version='1.0',              # Version du package
    packages=find_packages()    # Inclut tous les sous-packages automatiquement
)

# https://www.youtube.com/watch?v=Mgp6-ZMEcE